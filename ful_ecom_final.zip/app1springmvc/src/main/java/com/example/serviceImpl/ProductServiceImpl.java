package com.example.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Category;
import com.example.model.Product;
import com.example.repo.CartRepo;
import com.example.repo.OrderItemRepo;
import com.example.repo.OrderRepo;
import com.example.repo.ProductRepo;
import com.example.service.ProductService;

import jakarta.transaction.Transactional;
@Service
public class ProductServiceImpl implements ProductService  {
	
	@Autowired
	private ProductRepo productRepo;
	
	@Autowired
	private OrderItemRepo orderItemRepo;
	
	@Autowired
	private OrderRepo orderRepo;
	
	@Autowired
	private CartRepo cartRepo;

	@Override
	@Transactional
	public Product addProduct(Product productData) {
		return productRepo.save(productData);
	}

	@Override
	@Transactional
	public List<Product> getAllProducts() {
		List<Product> products = productRepo.findAll();
        return products;

	}

	@Override
	@Transactional
	public Product getProductById(Long productId) {
        Optional<Product> product = productRepo.findById(productId);
        return product.orElse(null);
	}

	@Override
	@Transactional
	public Product updateProduct(Product productData) {
		return productRepo.save(productData);
	}

	@Override
	@Transactional
	public Product updateProductDatas(Long product_id, String product_name, String description, double product_price,int stockQuantity, Category category , String imageData	) {
		Optional<Product> findProductById = productRepo.findById(product_id);
		System.out.println("product id found");
		if(findProductById.isPresent()) {
			Product product = findProductById.get();
			product.setProduct_name(product_name);
			product.setDescription(description);
			product.setProduct_price(product_price);
			product.setStockQuantity(stockQuantity);
			product.setCategory(category);
			product.setImageData(imageData);
			return productRepo.save(product);
		}else {
			return null;
		}
	}

	@Override
	@Transactional
	public void deleteProductById(Long product_id) {
	    Product product = productRepo.findById(product_id).orElseThrow(() -> new RuntimeException("Product not found"));
	    System.out.println("Deleting order items for product: " + product_id);
	    orderItemRepo.deleteByProductId(product_id);
	    
	    System.out.println("Deleting cart items for product: " + product_id);
	    cartRepo.deleteByProductId(product_id);
	    
	    System.out.println("Deleting product: " + product_id);
	    try {
	        productRepo.deleteById(product_id);
	    } catch (Exception e) {
	        System.err.println("Error deleting product: " + e.getMessage());
	    }
	    boolean exists = productRepo.existsById(product_id);
	    if (exists) {
	        System.out.println("Product not deleted: " + product_id);
	    } else {
	        System.out.println("Product successfully deleted: " + product_id);
	    }

	}


	@Override
	public Optional<Product> findProductById(Long productId) {
        return productRepo.findById(productId);
	}

	@Override
	public Product updateStockQuantity(Long productId, int stockQuantity) {
		Optional<Product> findProductById = productRepo.findById(productId);
		System.out.println("product id found");
		if(findProductById.isPresent()) {
			Product product = findProductById.get();
			product.setStockQuantity(stockQuantity);
			return productRepo.save(product);
		}else {
			return null;
		}
		
	}

	@Override
	public List<Product> searchProductsByName(String productName) {
	    return productRepo.searchByProductName(productName);
	}

	@Override
	public List<Product> searchProductsByCategory(Long categoryId) {
	    return productRepo.findByCategoryId(categoryId);

	}

//	@Override
//	public List<Product> searchProductsByName(String searchQuery) {
//        return productRepo.findByProductNameContainingIgnoreCase(searchQuery);
//	}

}
