package com.example.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.ProductDetailsDTO;
import com.example.model.Order;
import com.example.model.OrderItem;
import com.example.model.Payment;
import com.example.model.User;
import com.example.repo.OrderRepo;
import com.example.repo.PaymentRepo;
import com.example.service.OrderService;

import jakarta.transaction.Transactional;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepo orderRepo;
	
	@Autowired
	private PaymentRepo paymentRepo;
	
	@Override
	@Transactional
	public void saveOrder(Order order) {
		orderRepo.save(order);
	}

	@Override
	@Transactional
	public void savePayment(Payment payment) {
		paymentRepo.save(payment);
	}

	@Override
	@Transactional
	public List<Order> findByUser(User persistentUser) {
		return orderRepo.findByUser(persistentUser);
	}

	@Override
	@Transactional
	public List<Order> findAll() {
		return orderRepo.findAll();
	}

	@Override
	@Transactional
	public Optional<Order> findById(Long orderId) {
		return orderRepo.findById(orderId);
	}

	@Override
	@Transactional
	public void save(Order order) {
		orderRepo.save(order);
	}

	@Override
	@Transactional
    public List<Order> findByOrder(Order order) {
        return orderRepo.findByOrderid(order.getOrderid());
    }

	@Override
	@Transactional
	public List<Order> getOrdersByUser(User persistentUser) {
		return orderRepo.findByUser(persistentUser);
	}

//	@Override
//	@Transactional
//    public List<ProductDetailsDTO> getProductDetailsByOrderId(Long orderId) {
//        return orderRepo.findProductDetailsByOrderId(orderId);
//    }

}
