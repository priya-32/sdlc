package com.example.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.ProductDetailsDTO;
import com.example.model.Order;
import com.example.model.OrderItem;
import com.example.repo.OrderItemRepo;
import com.example.service.OrderItemService;

import jakarta.transaction.Transactional;

@Service
public class OrderItemServiceImpl implements OrderItemService {
	
	@Autowired
	private OrderItemRepo orderItemRepo;

	@Override
    public List<OrderItem> findByOrder(Order order) {
        return orderItemRepo.findByOrder(order);
    }

	@Override
	public void saveOrderItem(OrderItem orderItem) {
		 orderItemRepo.save(orderItem);
	}

	@Override
	public List<ProductDetailsDTO> getProductDetailsByOrderId(Long orderid) {
		return orderItemRepo.findProductDetailsByOrderId(orderid);
	}


}
