package com.example.service;

import java.util.List;

import com.example.model.Category;

public interface CategoryService {

	Category addCategory(Category categoryDatas);

	List<Category> getAllCategories();

	Category getCategoryById(Long categoryId);

}
