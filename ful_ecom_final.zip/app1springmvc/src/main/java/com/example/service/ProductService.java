package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.model.Category;
import com.example.model.Product;

public interface ProductService {

	Product addProduct(Product productData);

	List<Product> getAllProducts();

	Product getProductById(Long productId);

	Product updateProduct(Product productData);

	Product updateProductDatas(Long product_id, String product_name, String description, double product_price,int stockQuantity,Category category,String imageData);

	void deleteProductById(Long product_id);

	Optional<Product> findProductById(Long productId);

	Product updateStockQuantity(Long productId, int stockQuantity);

	List<Product> searchProductsByName(String productName);

	List<Product> searchProductsByCategory(Long categoryId);

//	List<Product> searchProductsByName(String searchQuery);

}
