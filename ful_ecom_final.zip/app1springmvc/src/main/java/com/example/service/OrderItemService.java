package com.example.service;

import java.util.List;

import com.example.dto.ProductDetailsDTO;
import com.example.model.Order;
import com.example.model.OrderItem;

import jakarta.transaction.Transactional;

public interface OrderItemService {
	List<OrderItem> findByOrder(Order order);

	void saveOrderItem(OrderItem orderItem);

	List<ProductDetailsDTO> getProductDetailsByOrderId(Long orderid);

	
}
