package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.dto.ProductDetailsDTO;
import com.example.model.Order;
import com.example.model.OrderItem;
import com.example.model.Payment;
import com.example.model.User;

public interface OrderService {

	void saveOrder(Order order);

	void savePayment(Payment payment);

	List<Order> findByUser(User persistentUser);

	List<Order> findAll();

	Optional<Order> findById(Long orderId);

	void save(Order order);

    List<Order> findByOrder(Order order);

	List<Order> getOrdersByUser(User persistentUser);

//	List<ProductDetailsDTO> getProductDetailsByOrderId(Long orderid);


}
