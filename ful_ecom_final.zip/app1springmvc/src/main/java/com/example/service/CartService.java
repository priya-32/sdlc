package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.model.Cart;
import com.example.model.Order;
import com.example.model.Product;
import com.example.model.User;

public interface CartService {

	Cart addProductToCart(Cart cart);




	Optional<Product> findProductById(Long product_id);




	List<Cart> getCartItemsByUser(User loggedInUser);




	void updateCart(Cart existingCartItem);




	void removeProductFromCart(User persistentUser, Long product_id);




	void updateProductQuantityInCart(User persistentUser, Long product_id, int quantity);
	
	
	
	void clearCart(User user);
	
	
	void decreaseStockQuantity(Product product, int quantity);




	int getCartCountByUser(User loggedInUser);





}
