package com.example.dto;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class ProductDetailsDTO {
    private String productName;
    private String description;
    private double productPrice;
    private int quantity;
    private String categoryName;
    private String imageData;
    
    public ProductDetailsDTO(String productName, String description, double productPrice, int quantity, String categoryName,String imageData) {
        this.productName = productName;
        this.description = description;
        this.productPrice = productPrice;
        this.quantity = quantity;
        this.categoryName = categoryName;
        this.imageData = imageData;
    }


}
