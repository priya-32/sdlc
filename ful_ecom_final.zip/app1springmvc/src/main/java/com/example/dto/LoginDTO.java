package com.example.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class LoginDTO {

    @NotEmpty(message="Username is blank")
    private String username;

    @NotEmpty(message="Password is blank")
    private String password;
    private String errorMessage;


}
