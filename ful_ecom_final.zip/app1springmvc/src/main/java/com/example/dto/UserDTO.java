package com.example.dto;

import com.example.enumerate.UserRole;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class UserDTO {

    @NotEmpty(message="Username is blank")
    @Size(min=8, max=20, message="Username must be between 3 and 20 characters")
    @Pattern(regexp="^[a-zA-Z0-9]{8,}$", message="Username should contain letters and numbers")
    private String username;

    @NotEmpty(message="Password is blank")
    @Size(min=8, message="Password must be at least 8 characters long")
    @Pattern(regexp="^(?=.*\\d)(?=.*[A-Za-z])(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$", 
             message="Password must be at least 8 characters long, contain at least one digit, one letter, and one special character")
    private String password;

    @Email(message="Email should be valid")
    @NotEmpty(message="Email is blank")
    private String email;

    private UserRole userrole;

    private String errorMessage; 
    }
