package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.dto.LoginDTO;
import com.example.dto.UserDTO;
import com.example.enumerate.UserRole;
import com.example.model.Cart;
import com.example.model.User;
import com.example.service.CartService;
import com.example.service.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping
public class AuthController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private CartService cartService;


    @GetMapping("/register")
    public String getRegisterPage(ModelMap map) {
        map.addAttribute("user", new UserDTO()); // Add an empty user DTO object
        return "registerForm"; // Fetch the form and map the form data to the user attributes
    }

    @PostMapping("/register")
    public String postRegisterDetails(
            @ModelAttribute("user") @Valid UserDTO userdto,
            BindingResult result,
            ModelMap map) {
        if (result.hasErrors()) {
            return "registerForm"; // Return the form view with error messages
        }

        // Map UserDTO to User entity
        User user = new User();
        user.setUsername(userdto.getUsername());
        user.setPassword(userdto.getPassword());
        user.setEmail(userdto.getEmail());
        user.setUserrole(userdto.getUserrole());

        userService.saveUser(user);
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String getLoginPage(HttpSession session, ModelMap map) {
        User userfound = (User) session.getAttribute("loggedInUser");
        if (userfound != null) {
            if (userfound.getUserrole() == UserRole.ADMIN) {
                return "redirect:/admin/home";
            } else {
                return "redirect:/customer/home";
            }
        }
        map.addAttribute("userlogin", new LoginDTO());
        return "loginForm";
    }

    @PostMapping("/login")
    public String postLoginDetails(
            @ModelAttribute("userlogin") @Valid LoginDTO logindto,
            BindingResult result,
            HttpSession session,
            ModelMap map) {
        if (result.hasErrors()) {
            System.out.println("Validation errors found");

            return "loginForm";
        }

        User userfound = userService.authenticate(logindto.getUsername(), logindto.getPassword());
        List<Cart> cartItems = cartService.getCartItemsByUser(userfound);
        int totalItems = cartItems.stream().mapToInt(Cart::getQuantity).sum();
        session.setAttribute("totalItems", totalItems);

        if (userfound != null) {
            session.setAttribute("loggedInUser", userfound);
            return userfound.getUserrole() == UserRole.ADMIN ? "redirect:/admin/home" : "redirect:/customer/home";
        } else {
            map.addAttribute("errorMessage", "Invalid username or password.");
            return "loginForm";
        }
    }

}
