package com.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.enumerate.UserRole;
import com.example.model.Cart;
import com.example.model.Category;
import com.example.model.Product;
import com.example.model.User;
import com.example.service.CartService;
import com.example.service.CategoryService;
import com.example.service.ProductService;
import com.example.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private CategoryService categoryService;
	
	@GetMapping("/")
	public String showHome() {
		return "home";
	}

	
    @GetMapping("/home")
    public String showCustomerHome(HttpSession session, ModelMap model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            System.err.println("User is not authenticated");
            return "redirect:/login";
        }

        System.out.println("Authenticated user: " + user);
        System.out.println("User ID: " + user.getUserid());
        System.out.println("User Email: " + user.getEmail());
        System.out.println("User Username: " + user.getUsername());

        // Fetch the user from the database
        Optional<User> optionalUser = userService.findById(user.getUserid());
        if (!optionalUser.isPresent()) {
            // Log the error
            System.err.println("User not found: " + user.getUserid());
            return "redirect:/error?message=User not found"; 
        }
        User persistentUser = optionalUser.get();

        // Add user data to the model
        model.addAttribute("loggedInUser", persistentUser);


        return "customerdashboard";
    }
	
    @GetMapping("/listProduct")
    public String listProducts(ModelMap model) {
        List<Product> products = productService.getAllProducts();
		List<Category> categories = categoryService.getAllCategories();
        System.out.println("Categories: " + categories);
        model.addAttribute("products", products);
        model.addAttribute("categories", categories);
        return "custProduct";
    }
	
	@GetMapping("/cart")
	public String viewCart(ModelMap model, HttpSession session) {
	    User loggedInUser = (User) session.getAttribute("loggedInUser");
	    if (loggedInUser == null) {
	        return "redirect:/login";
	    }

	    List<Cart> cartItems = cartService.getCartItemsByUser(loggedInUser);
	    cartItems.forEach(item -> System.out.println("CartItem: " + item.getProduct().getProduct_name() + ", Quantity: " + item.getQuantity()));

	    model.addAttribute("cartItems", cartItems);

	    double totalPrice = cartItems.stream()
	                                 .mapToDouble(item -> item.getProduct().getProduct_price() * item.getQuantity())
	                                 .sum();
	    model.addAttribute("totalPrice", totalPrice);

	    return "addtocart";
	}

}
