package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.model.Category;
import com.example.service.CategoryService;

@Controller
@RequestMapping("/category")
public class CategoryController {
	
	@Autowired
	private CategoryService categoryService;
	
	@GetMapping("/ListAllCategory")
	public String listCategoryForm(ModelMap map) {
		List<Category>categories =categoryService.getAllCategories();
		map.addAttribute("category",categories);
		return "listCategoryDetails";
	}
	
	@GetMapping("/addCategory")
	public String showaddCategoryForm(ModelMap map) {
		map.addAttribute("category" , new Category());
		return "addCategoryForm";
	}
	
	@PostMapping("/addCategory")
	public String addCategory(
			@ModelAttribute("category") Category categoryData , 
			ModelMap model
			) {
		try {
			Category categorysdata = categoryService.addCategory(categoryData);
			model.addAttribute("category",categorysdata);
			return "redirect:/admin/category";
		}catch(Exception e) {
			return "error";
		}
	}

}
