package com.example.controller;
import java.beans.PropertyEditorSupport;
import java.util.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.dto.LoginDTO;
import com.example.dto.UserDTO;
import com.example.enumerate.UserRole;
import com.example.model.User;
import com.example.service.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	
	
	@GetMapping("/getAlluser")
	public String getAllUsers(ModelMap map,HttpSession session) {
		if((User)session.getAttribute("loggedInUser")!=null) {
			return "redirect:/login";
		}
		List<User>  userList = userService.getAllUsers();
		map.addAttribute("user",userList );
		return "userdata";
	}
	


	
//	update user details 
	
	@GetMapping("/update")
	public String showUpdateForm(@RequestParam("userid") long userid, ModelMap map) {
	    User user = userService.getUserById(userid);
	    map.addAttribute("user", user);
	    return "updateUser";
	}

	@PostMapping("/update")
	public String updateUserData(
	        @RequestParam("userid") long userid,
	        @RequestParam("username") String username,
	        @RequestParam("email") String email,
	        @RequestParam("password") String password,
	        ModelMap map) {
	    System.out.println("update");
	    User updatedUser = userService.updateUserDetails(userid, username, email, password);
	    if (updatedUser != null) {
	        System.out.println("update successful");
	        map.addAttribute("user", updatedUser);
	        return "redirect:/customer/home";
	    } else {
	        return "error";
	    }
	}
	
	@GetMapping("/delete")
	public String showdeleteUserForm(ModelMap map 
			) {
		map.addAttribute("user",new User());
		return "deleteUserForm";
	}
	
	@PostMapping("/delete")
	public String deleteUser(@ModelAttribute("userid") Long userid , ModelMap map) {
		userService.deleteUserById(userid);
		return "redirect:/user/listUser";
	}
	
//	list all user
	
	@GetMapping("/listUser")
	public String listAllUserData(ModelMap map) {
		List<User> listUser = userService.getAllUsers();
		map.addAttribute("user",listUser);
		return "listUserDetails";
	}
	
//	add user
	@GetMapping("/add")
	public String showaddUserForm(ModelMap map) {
		map.addAttribute("user",new User());
		return "addUserForm";
	}
	@PostMapping("/add")
	public String addUserData(@ModelAttribute("user") User user ,ModelMap map) {
		User userData = userService.addUser(user);
		map.addAttribute("user",userData);
		return "redirect:/user/listUser";
	}
	
//	update user
	
}
