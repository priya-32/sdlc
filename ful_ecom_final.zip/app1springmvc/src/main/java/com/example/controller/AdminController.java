package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.enumerate.UserRole;
import com.example.model.Category;
import com.example.model.Product;
import com.example.model.User;
import com.example.service.CategoryService;
import com.example.service.ProductService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private ProductService productService;


	
	@GetMapping("/home")
	public String showAdminHome(HttpSession session) {
	    User userfound = (User) session.getAttribute("loggedInUser");
	    if (userfound != null && userfound.getUserrole() == UserRole.ADMIN) {
	        return "admindashboard";
	    } else {
	        return "redirect:/login";
	    }
	}	@GetMapping("/logout")
	public String logout(HttpServletRequest request,HttpSession session) {
	    request.getSession().invalidate();
	    return "redirect:/login";
	}
	@GetMapping("/product")
	public String product() {
		return "product";
	}
	@GetMapping("/user")
	public String user() {
		return "user";
	}
	
	@GetMapping("/category")
	public String category() {
		return "category";
	}
	
	@GetMapping("/order")
	public String order() {
		return "order";
	}
	
	@GetMapping("/listCategoryData")
	public String listCategoryData(ModelMap map) {
		List<Category>categories =categoryService.getAllCategories();
		map.addAttribute("categories",categories);

		return "listCategoryData";
	}
	
    @GetMapping("/search")
    public String searchProduct(@RequestParam("productName") String productName, ModelMap model) {
        List<Product> products = productService.searchProductsByName(productName);
        model.addAttribute("products", products);
        List<Category> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);

        return "productList";
    }
    @GetMapping("/searchByCategory")
    public String searchProductsByCategorys(@RequestParam(value = "categoryId", required = false) Long categoryId, ModelMap model, HttpSession session) {
        List<Product> products;
        if (categoryId != null && categoryId != 0) {
            products = productService.searchProductsByCategory(categoryId);
        } else {
            products = productService.getAllProducts();
        }
        model.addAttribute("products", products);

        List<Category> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);

        User userfound = (User) session.getAttribute("loggedInUser");
        if (userfound != null && userfound.getUserrole() == UserRole.ADMIN) {
            return "productList";
        } else {
            return "redirect:/login";
        }
    }

}
