package com.example.controller;

import java.util.ArrayList;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.dto.ProductDetailsDTO;
import com.example.enumerate.OrderStatus;
import com.example.model.Cart;
import com.example.model.Order;
import com.example.model.OrderItem;
import com.example.model.Payment;
import com.example.model.Product;
import com.example.model.User;
import com.example.service.CartService;
import com.example.service.OrderItemService;
import com.example.service.OrderService;
import com.example.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/order")
public class OrderController {
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private OrderItemService orderItemService;
	
	
	@GetMapping("/checkout")
	public String showCheckOutPage(@AuthenticationPrincipal User user , ModelMap model , HttpSession session) {
		User loggedInUser = (User) session.getAttribute("loggedInUser");
		if(loggedInUser == null) {
			System.err.println("USer is not found");
			return "redirect:/login";
		}
		Optional<User> optionalUser = userService.findById(loggedInUser.getUserid());
		if(!optionalUser.isPresent()) {
			System.err.println("User not found: "+loggedInUser.getUserid());
			return "redirect:/error?message=User not found";
		}
		User persistentUser = optionalUser.get();
		List<Cart> cartItems = cartService.getCartItemsByUser(persistentUser);
		if(cartItems.isEmpty()) {
			System.err.println("Cart is empty for user: "+loggedInUser.getUserid());
			return "redirect:/error?message=Cart is empty";
		}
		double totalAmount = cartItems.stream()
				                      .mapToDouble(item ->
				                      item.getProduct().getProduct_price()*item.getQuantity())
				                      .sum();
		Order order = new Order();
		order.setUser(persistentUser);
		order.setTotalAmount(totalAmount);
		order.setOrderDate(new Date());
		order.setOrderStatus(OrderStatus.PENDING);
		
		model.addAttribute("order", order);
		model.addAttribute("cartItems", cartItems);
		model.addAttribute("totalAmount", totalAmount);
		
		return "checkout";
	}
	
	@PostMapping("/placeOrder")
	public String placeOrder(@AuthenticationPrincipal User user, HttpSession session, @RequestParam("paymentMethod") String paymentMethod) {
	    User loggedInUser = (User) session.getAttribute("loggedInUser");
	    if (loggedInUser == null) {
	        System.err.print("User is not found");
	        return "redirect:/login";
	    }
	    Optional<User> optionalUser = userService.findById(loggedInUser.getUserid());
	    if (!optionalUser.isPresent()) {
	        System.err.println("User not found: " + loggedInUser.getUserid());
	        return "redirect:/error?message=User not found";
	    }
	    User persistentUser = optionalUser.get();
	    List<Cart> cartItems = cartService.getCartItemsByUser(persistentUser);
	    if (cartItems.isEmpty()) {
	        System.err.println("Cart is empty for user: " + loggedInUser.getUserid());
	        return "redirect:/error?message=Cart is empty";
	    }
	    
	    double totalAmount = cartItems.stream()
	            .mapToDouble(item -> item.getProduct().getProduct_price() * item.getQuantity())
	            .sum();
	    
	    Order order = new Order();
	    order.setUser(persistentUser);
	    order.setTotalAmount(totalAmount);
	    order.setOrderDate(new Date());
	    order.setOrderStatus(OrderStatus.PENDING);

	    // Save the order first
	    orderService.saveOrder(order);

	    // Now create OrderItems
	    List<OrderItem>orderItems=new ArrayList<>();
	    for (Cart cartItem : cartItems) {
	        OrderItem orderItem = new OrderItem();
	        orderItem.setOrder(order);
	        orderItem.setProduct(cartItem.getProduct());
	        orderItem.setQuantity(cartItem.getQuantity());
	        orderItems.add(orderItem);
	        orderItemService.saveOrderItem(orderItem); // Ensure this method exists in your service
	    }
	    order.setOrderItems(orderItems);
	    orderService.saveOrder(order);
	    Payment payment = new Payment();
	    payment.setOrder(order);
	    payment.setAmount(totalAmount);
	    payment.setPaymentMethod(paymentMethod);
	    payment.setPaymentDate(new Date());

	    orderService.savePayment(payment);

	    // Update the order with the payment date
	    order.setPaymentDate(payment.getPaymentDate());
	    orderService.saveOrder(order);

	    // Decrease the stock quantity for each product in the cart
	    for (Cart cartItem : cartItems) {
	        Product product = cartItem.getProduct();
	        cartService.decreaseStockQuantity(product, cartItem.getQuantity());
	    }
	    cartService.clearCart(persistentUser);
	    session.setAttribute("totalItems", 0);

	    System.out.println("Cart count after clearing: " + session.getAttribute("totalItems"));
	    return "redirect:/order/confirmation";
	}
	
	@GetMapping("/confirmation")
	public String orderConfirmation() {
		return "orderConfirmation";
	}
	

	
	@GetMapping("/myOrders")
	public String getUserOrders(@AuthenticationPrincipal User user, HttpSession session, ModelMap model) {
	    User loggedInUser = (User) session.getAttribute("loggedInUser");
	    if (loggedInUser == null) {
	        System.err.print("User is not found");
	        return "redirect:/login";
	    }
	    Optional<User> optionalUser = userService.findById(loggedInUser.getUserid());
	    if (!optionalUser.isPresent()) {
	        System.err.println("User not found: " + loggedInUser.getUserid());
	        return "redirect:/error?message=User not found";
	    }
	    User persistentUser = optionalUser.get();
	    List<Order> orders = orderService.getOrdersByUser(persistentUser);
	    
	    // Fetch product details for each order
	    Map<Long, List<ProductDetailsDTO>> orderProductDetails = new HashMap<>();
	    for (Order order : orders) {
	        List<ProductDetailsDTO> productDetails = orderItemService.getProductDetailsByOrderId(order.getOrderid());
	        System.out.println(order.getOrderid()+" "+productDetails);
	        orderProductDetails.put(order.getOrderid(), productDetails);
	    }
	    
	    model.addAttribute("orders", orders);
	    model.addAttribute("orderProductDetails", orderProductDetails);
	    return "userOrderList";
	}
	
    @GetMapping("/getAllorders")
    public String viewAllOrders(ModelMap model) {
        List<Order> orders = orderService.findAll();
        model.addAttribute("orders", orders);
        model.addAttribute("orderStatuses", OrderStatus.values());
        return "adminOrderList";
    }

    @PostMapping("/updateOrderStatus")
    public String updateOrderStatus(@RequestParam("orderId") Long orderId, @RequestParam("status") OrderStatus status, RedirectAttributes redirectAttributes) {
        Optional<Order> optionalOrder = orderService.findById(orderId);
        if (optionalOrder.isPresent()) {
            Order order = optionalOrder.get();
            order.setOrderStatus(status);
            orderService.save(order);
            redirectAttributes.addFlashAttribute("message", "Order status updated successfully.");
        } else {
            redirectAttributes.addFlashAttribute("error", "Order not found.");
        }
        return "redirect:/order/getAllorders";
    }

}
