package com.example.repo;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.dto.ProductDetailsDTO;
import com.example.model.Order;
import com.example.model.OrderItem;
import com.example.model.Product;

@Repository
public interface OrderItemRepo extends JpaRepository<OrderItem, Long> {
	
	
	@Query("SELECT new com.example.dto.ProductDetailsDTO(p.product_name, p.description, p.product_price, oi.quantity, c.category_name,p.imageData) " +
	        "FROM Order o JOIN o.orderItems oi JOIN oi.product p JOIN p.category c " +
	        "WHERE o.orderid = :orderid")
	List<ProductDetailsDTO> findProductDetailsByOrderId(@Param("orderid") Long orderid);

    List<OrderItem> findByOrder(Order order);
    
    
    @Modifying
    @Query("DELETE FROM OrderItem oi WHERE oi.product.id = :productId")
    void deleteByProductId(@Param("productId") Long productId);



}
