package com.example.repo;

import java.util.List;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.dto.ProductDetailsDTO;
import com.example.model.Order;
import com.example.model.Product;
import com.example.model.User;

@Repository
public interface OrderRepo extends JpaRepository<Order, Long> {

	List<Order> findByUser(User persistentUser);

	List<Order> findByOrderid(Long orderid);


//    @Query("SELECT new com.example.model.ProductDetailsDTO(p.product_name, p.description, p.product_price, ci.quantity, c.category_name) " +
//            "FROM Order o JOIN o.cartItems ci JOIN ci.product p JOIN p.category c " +
//            "WHERE o.orderid = :orderid")
//     List<ProductDetailsDTO> findProductDetailsByOrderId(@Param("orderid") Long orderid);
//
}
