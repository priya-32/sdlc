package com.example.repo;


import org.springframework.data.jpa.repository.Modifying;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.model.Product;
@Repository
public interface ProductRepo extends JpaRepository<Product, Long> {

    
    @Modifying
    @Query("DELETE FROM Product p WHERE p.product_id = :productId")
    void deleteById(@Param("productId") Long productId);

    @Query("SELECT p FROM Product p WHERE LOWER(p.product_name) LIKE LOWER(CONCAT('%', :product_name, '%'))")
    List<Product> searchByProductName(@Param("product_name") String product_name);

    @Query("SELECT p FROM Product p WHERE p.category.category_id = :categoryId")
    List<Product> findByCategoryId(@Param("categoryId") Long categoryId);


}
