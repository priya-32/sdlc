package com.example.enumerate;

public enum OrderStatus {
	
	 PENDING,SHIPPED,DELIVERED,CANCELLED ;

	    public String getString() {
	        return this.name();
	    }

}
