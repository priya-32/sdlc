package com.example.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="payment")
@Getter
@Setter
public class Payment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long paymentid;
	
	@OneToOne
	@JoinColumn(name="orderid",referencedColumnName = "orderid" , nullable = false)
	@JsonBackReference
	private Order order;
	
	@Column(nullable = false)
	private double amount;
	
	@Column(nullable = false)
	private String paymentMethod;
	
	@Temporal(TemporalType.DATE)
	private Date paymentDate;


}
