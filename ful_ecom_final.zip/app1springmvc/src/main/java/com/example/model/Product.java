package com.example.model;

import java.util.List;
import java.util.Set;

import com.example.enumerate.UserRole;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="product")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long product_id;
	
	@Column(nullable=false,length=50)
	private String product_name;
	
	@Column(nullable=false,length=150)
	private String description;
	
	@Column(nullable=false)
	private double product_price;
	
	@Column(nullable=false)
	private int stockQuantity;
	
	@ManyToOne
	@JoinColumn(name="categoryid")
	private Category category;
	
	private String imageData;
	
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OrderItem> orderItems;
    
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Cart> carts;

    public Product(Long product_id, String product_name, String description, double product_price, int stockQuantity, Category category, String imageData) {
        this.product_id = product_id;
        this.product_name = product_name;
        this.description = description;
        this.product_price = product_price;
        this.stockQuantity = stockQuantity;
        this.category = category;
        this.imageData = imageData;
    }


	
}
