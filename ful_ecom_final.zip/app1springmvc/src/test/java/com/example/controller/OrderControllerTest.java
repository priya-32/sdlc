package com.example.controller;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.model.Cart;
import com.example.model.Order;
import com.example.model.Product;
import com.example.model.User;
import com.example.service.CartService;
import com.example.service.OrderItemService;
import com.example.service.OrderService;
import com.example.service.UserService;

import java.util.Arrays;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class OrderControllerTest {

    @Mock
    private CartService cartService;

    @Mock
    private OrderService orderService;

    @Mock
    private UserService userService;

    @Mock
    private OrderItemService orderItemService;

    @InjectMocks
    private OrderController orderController;

    private MockMvc mockMvc;

    private User user;
    private Product product;
    private Cart cart;
    private Order order;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(orderController).build();

        user = new User();
        user.setUserid(1L);

        product = new Product();
        product.setProduct_id(1L);
        product.setStockQuantity(10);

        cart = new Cart();
        cart.setCartId(1L);
        cart.setUser(user);
        cart.setProduct(product);
        cart.setQuantity(2);

        order = new Order();
        order.setOrderid(1L);
        order.setUser(user);
        order.setTotalAmount(100.0);
    }


    @Test
    public void testPlaceOrder() throws Exception {
        when(userService.findById(anyLong())).thenReturn(Optional.of(user));
        when(cartService.getCartItemsByUser(any(User.class))).thenReturn(Arrays.asList(cart));

        mockMvc.perform(post("/order/placeOrder")
                .param("paymentMethod", "Credit Card")
                .sessionAttr("loggedInUser", user))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/order/confirmation"));
    }

    @Test
    public void testOrderConfirmation() throws Exception {
        mockMvc.perform(get("/order/confirmation"))
                .andExpect(status().isOk())
                .andExpect(view().name("orderConfirmation"));
    }

    @Test
    public void testGetUserOrders() throws Exception {
        when(userService.findById(anyLong())).thenReturn(Optional.of(user));
        when(orderService.getOrdersByUser(any(User.class))).thenReturn(Arrays.asList(order));

        mockMvc.perform(get("/order/myOrders").sessionAttr("loggedInUser", user))
                .andExpect(status().isOk())
                .andExpect(view().name("userOrderList"))
                .andExpect(model().attributeExists("orders"))
                .andExpect(model().attributeExists("orderProductDetails"));
    }

    @Test
    public void testViewAllOrders() throws Exception {
        when(orderService.findAll()).thenReturn(Arrays.asList(order));

        mockMvc.perform(get("/order/getAllorders"))
                .andExpect(status().isOk())
                .andExpect(view().name("adminOrderList"))
                .andExpect(model().attributeExists("orders"))
                .andExpect(model().attributeExists("orderStatuses"));
    }

    @Test
    public void testUpdateOrderStatus() throws Exception {
        when(orderService.findById(anyLong())).thenReturn(Optional.of(order));

        mockMvc.perform(post("/order/updateOrderStatus")
                .param("orderId", "1")
                .param("status", "SHIPPED"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/order/getAllorders"));
    }
}
