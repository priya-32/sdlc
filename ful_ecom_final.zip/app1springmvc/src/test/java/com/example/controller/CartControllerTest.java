package com.example.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.Optional;

import com.example.model.Cart;
import com.example.model.Product;
import com.example.model.User;
import com.example.service.CartService;
import com.example.service.UserService;

@ExtendWith(MockitoExtension.class)
public class CartControllerTest {

    @Mock
    private CartService cartService;

    @Mock
    private UserService userService;

    @InjectMocks
    private CartController cartController;

    private MockMvc mockMvc;

    private User user;
    private Product product;
    private Cart cart;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(cartController).build();

        user = new User();
        user.setUserid(1L);

        product = new Product();
        product.setProduct_id(1L);
        product.setStockQuantity(10);

        cart = new Cart();
        cart.setCartId(1L);
        cart.setUser(user);
        cart.setProduct(product);
        cart.setQuantity(2);
    }

    @Test
    public void testAddProductToCart() throws Exception {
        when(cartService.findProductById(anyLong())).thenReturn(Optional.of(product));
        when(cartService.getCartItemsByUser(any(User.class))).thenReturn(Arrays.asList(cart));

        mockMvc.perform(post("/cart/add")
                .param("product_id", "1")
                .param("quantity", "2")
                .sessionAttr("loggedInUser", user))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/product/listAllProduct"));
    }

    @Test
    public void testRemoveProductFromCart() throws Exception {
        when(userService.findById(anyLong())).thenReturn(Optional.of(user));
        when(cartService.findProductById(anyLong())).thenReturn(Optional.of(product));

        mockMvc.perform(post("/cart/remove")
                .param("product_id", "1")
                .sessionAttr("loggedInUser", user))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/customer/cart"));
    }

    @Test
    public void testUpdateCart() throws Exception {
        when(cartService.findProductById(anyLong())).thenReturn(Optional.of(product));

        mockMvc.perform(post("/cart/update")
                .param("product_id", "1")
                .param("quantity", "5")
                .sessionAttr("loggedInUser", user))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/customer/cart"));
    }
}
