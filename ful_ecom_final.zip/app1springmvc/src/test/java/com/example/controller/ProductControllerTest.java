package com.example.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.model.Category;
import com.example.model.Product;
import com.example.service.CategoryService;
import com.example.service.ProductService;

import java.util.Arrays;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class ProductControllerTest {

    @Mock
    private ProductService productService;

    @Mock
    private CategoryService categoryService;

    @InjectMocks
    private ProductController productController;

    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(productController).build();
    }

    @Test
    public void testShowAddProductForm() throws Exception {
        List<Category> categories = Arrays.asList(new Category(1L, "Electronics"), new Category(2L, "Books"));
        when(categoryService.getAllCategories()).thenReturn(categories);

        mockMvc.perform(get("/product/addProduct"))
                .andExpect(status().isOk())
                .andExpect(view().name("addProductForm"))
                .andExpect(model().attributeExists("product"))
                .andExpect(model().attribute("categories", categories));
    }

    @Test
    public void testAddProduct() throws Exception {
        Category category = new Category(1L, "Electronics");

        Product products = new Product(1L, "Laptop", "High-end laptop", 1200.00, 10, new Category(1L, "Electronics"), "imageData");
        when(productService.addProduct(any(Product.class))).thenReturn(products);

        mockMvc.perform(post("/product/addProduct")
                .param("product_name", "Laptop")
                .param("description", "High-end laptop")
                .param("product_price", "1200.00")
                .param("stockQuantity", "10")
                .param("category.id", "1L")
                .param("imageData", "imageData"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/product/listProducts"));
    }

    @Test
    public void testListProducts() throws Exception {
        List<Product> products = Arrays.asList(new Product(1L, "Laptop", "High-end laptop", 1200.00, 10, new Category(1L, "Electronics"), "imageData"));
        when(productService.getAllProducts()).thenReturn(products);

        mockMvc.perform(get("/product/listProducts"))
                .andExpect(status().isOk())
                .andExpect(view().name("productList"))
                .andExpect(model().attribute("products", products));
    }
//    @Test
//    public void testUpdateProductData() throws Exception {
//        Category category = new Category(1L, "Electronics");
//
//        Product updatedProduct = new Product(1L, "Laptop", "High-end laptop", 1200.00, 10, new Category(1L, "Electronics"), "imageData");
//        when(productService.updateProductDatas(anyLong(), anyString(), anyString(), anyDouble(), anyInt(), any(Category.class), anyString())).thenReturn(updatedProduct);
//
//        mockMvc.perform(post("/product/updateproduct")
//                .param("product_id", "1")
//                .param("product_name", "Laptop")
//                .param("description", "High-end laptop")
//                .param("product_price", "1200.00")
//                .param("stockQuantity", "10")
//                .param("category", "category")
//                .param("imageData", "imageData"))
//                .andExpect(status().is3xxRedirection())
//                .andExpect(redirectedUrl("/product/listProducts"));
//    }

}
