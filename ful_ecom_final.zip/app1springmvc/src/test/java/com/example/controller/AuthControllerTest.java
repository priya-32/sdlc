package com.example.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.*;

import com.example.dto.LoginDTO;
import com.example.dto.UserDTO;
import com.example.enumerate.UserRole;
import com.example.model.User;
import com.example.service.CartService;
import com.example.service.UserService;

@ExtendWith(MockitoExtension.class)
public class AuthControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private AuthController authController;
    
    @Mock
    private CartService cartService;


    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(authController).build();
    }

    @Test
    public void testGetRegisterPage() throws Exception {
        mockMvc.perform(get("/register"))
                .andExpect(status().isOk())
                .andExpect(view().name("registerForm"))
                .andExpect(model().attributeExists("user"));
    }

    @Test
    public void testPostRegisterDetails() throws Exception {
        UserDTO userDTO = new UserDTO();
        userDTO.setUsername("testuser");
        userDTO.setPassword("password@121");
        userDTO.setEmail("test@example.com");
        userDTO.setUserrole(UserRole.CUSTOMER);

        mockMvc.perform(post("/register")
                .flashAttr("user", userDTO))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));

        verify(userService, times(1)).saveUser(any(User.class));
    }

    @Test
    public void testGetLoginPage() throws Exception {
        mockMvc.perform(get("/login"))
                .andExpect(status().isOk())
                .andExpect(view().name("loginForm"))
                .andExpect(model().attributeExists("userlogin"));
    }

    @Test
    public void testPostLoginDetails_Success() throws Exception {
        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setUsername("testuser");
        loginDTO.setPassword("password@121");

        User user = new User();
        user.setUsername("testuser");
        user.setUserrole(UserRole.CUSTOMER);

        when(userService.authenticate("testuser", "password@121")).thenReturn(user);

        mockMvc.perform(post("/login")
                .flashAttr("userlogin", loginDTO))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/customer/home"));

        verify(userService, times(1)).authenticate("testuser", "password@121");
    }

    @Test
    public void testPostLoginDetails_Failure() throws Exception {
        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setUsername("wronguser");
        loginDTO.setPassword("wrongpassword@123"); 

        when(userService.authenticate("wronguser", "wrongpassword@123")).thenReturn(null);

        mockMvc.perform(post("/login")
                .flashAttr("userlogin", loginDTO))
                .andExpect(status().isOk())
                .andExpect(view().name("loginForm"))
                .andExpect(model().attributeExists("errorMessage"))
                .andExpect(model().attribute("errorMessage", "Invalid username or password."));

        verify(userService, times(1)).authenticate("wronguser", "wrongpassword@123");

        User result = userService.authenticate("wronguser", "wrongpassword@123");
        assertNull(result, "Expected authentication to fail and return null");
    }
}
