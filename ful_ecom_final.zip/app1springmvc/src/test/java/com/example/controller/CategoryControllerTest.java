package com.example.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.model.Category;
import com.example.service.CategoryService;

import java.util.Arrays;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class CategoryControllerTest {

    @Mock
    private CategoryService categoryService;

    @InjectMocks
   private CategoryController categoryController;

    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(categoryController).build();
    }

    @Test
    public void testListCategoryForm() throws Exception {
        List<Category> categories = Arrays.asList(new Category(1L, "Electronics"), new Category(2L, "Books"));
        when(categoryService.getAllCategories()).thenReturn(categories);

        mockMvc.perform(get("/category/ListAllCategory"))
                .andExpect(status().isOk())
                .andExpect(view().name("listCategoryDetails"))
                .andExpect(model().attributeExists("category"))
                .andExpect(model().attribute("category", categories));
    }

    @Test
    public void testShowAddCategoryForm() throws Exception {
        mockMvc.perform(get("/category/addCategory"))
                .andExpect(status().isOk())
                .andExpect(view().name("addCategoryForm"))
                .andExpect(model().attributeExists("category"));
    }

    @Test
    public void testAddCategory() throws Exception {
        Category category = new Category(1L, "Electronics");
        when(categoryService.addCategory(any(Category.class))).thenReturn(category);

        mockMvc.perform(post("/category/addCategory")
                .flashAttr("category", category))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/category")); // Ensure the URL matches the redirection
    }
}
