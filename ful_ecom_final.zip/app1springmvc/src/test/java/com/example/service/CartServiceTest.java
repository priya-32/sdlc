package com.example.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

import com.example.model.Cart;
import com.example.model.Product;
import com.example.model.User;
import com.example.repo.CartRepo;
import com.example.repo.ProductRepo;
import com.example.serviceImpl.CartServiceImpl;

@ExtendWith(MockitoExtension.class)
public class CartServiceTest {

    @Mock
    private CartRepo cartRepo;

    @Mock
    private ProductRepo productRepo;

    @InjectMocks
    private CartServiceImpl cartService;

    private User user;
    private Product product;
    private Cart cart;

    @BeforeEach
    public void setUp() {
        user = new User();
        user.setUserid(1L);

        product = new Product();
        product.setProduct_id(1L);
        product.setStockQuantity(10);

        cart = new Cart();
        cart.setCartId(1L);
        cart.setUser(user);
        cart.setProduct(product);
        cart.setQuantity(2);
    }

    @Test
    public void testAddProductToCart() {
        when(cartRepo.save(any(Cart.class))).thenReturn(cart);

        Cart savedCart = cartService.addProductToCart(cart);

        assertNotNull(savedCart);
        assertEquals(cart.getCartId(), savedCart.getCartId());
        verify(cartRepo, times(1)).save(cart);
    }

    @Test
    public void testFindProductById() {
        when(productRepo.findById(anyLong())).thenReturn(Optional.of(product));

        Optional<Product> foundProduct = cartService.findProductById(1L);

        assertTrue(foundProduct.isPresent());
        assertEquals(product.getProduct_id(), foundProduct.get().getProduct_id());
        verify(productRepo, times(1)).findById(1L);
    }

    @Test
    public void testGetCartItemsByUser() {
        List<Cart> cartItems = Arrays.asList(cart);
        when(cartRepo.findByUser(any(User.class))).thenReturn(cartItems);

        List<Cart> result = cartService.getCartItemsByUser(user);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(cartRepo, times(1)).findByUser(user);
    }

    @Test
    public void testRemoveProductFromCart() {
        List<Cart> cartItems = Arrays.asList(cart);
        when(cartRepo.findByUser(any(User.class))).thenReturn(cartItems);

        cartService.removeProductFromCart(user, 1L);

        verify(cartRepo, times(1)).delete(cart);
    }

    @Test
    public void testUpdateProductQuantityInCart() {
        when(cartRepo.findByUserAndProductId(any(User.class), anyLong())).thenReturn(cart);

        cartService.updateProductQuantityInCart(user, 1L, 5);

        assertEquals(5, cart.getQuantity());
        verify(cartRepo, times(1)).save(cart);
    }

    @Test
    public void testClearCart() {
        List<Cart> cartItems = Arrays.asList(cart);
        when(cartRepo.findByUser(any(User.class))).thenReturn(cartItems);

        cartService.clearCart(user);

        verify(cartRepo, times(1)).deleteAll(cartItems);
    }
}
