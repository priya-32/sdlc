package com.example.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.model.Category;
import com.example.repo.CategoryRepo;
import com.example.serviceImpl.CategoryServiceImpl;

@ExtendWith(MockitoExtension.class)
public class CategoryServiceTest {

    @Mock
    private CategoryRepo categoryRepo;

    @InjectMocks
    private CategoryServiceImpl categoryService;

    private Category category;

    @BeforeEach
    public void setUp() {
        category = new Category(1L, "Electronics");
    }

    @Test
    public void testAddCategory() {
        doReturn(category).when(categoryRepo).save(any(Category.class));

        Category savedCategory = categoryService.addCategory(category);

        assertNotNull(savedCategory);
        assertEquals(category.getCategory_name(), savedCategory.getCategory_name());
        verify(categoryRepo, times(1)).save(category);
    }

    @Test
    public void testGetAllCategories() {
        List<Category> categories = Arrays.asList(category);
        doReturn(categories).when(categoryRepo).findAll();

        List<Category> result = categoryService.getAllCategories();

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(categoryRepo, times(1)).findAll();
    }

    @Test
    public void testGetCategoryById() {
        doReturn(Optional.of(category)).when(categoryRepo).findById(anyLong());

        Category result = categoryService.getCategoryById(1L);

        assertNotNull(result);
        assertEquals(category.getCategory_name(), result.getCategory_name());
        verify(categoryRepo, times(1)).findById(1L);
    }
}
