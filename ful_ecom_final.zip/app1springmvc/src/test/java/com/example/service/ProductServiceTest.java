package com.example.service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.model.Category;
import com.example.model.Product;
import com.example.repo.CartRepo;
import com.example.repo.OrderItemRepo;
import com.example.repo.OrderRepo;
import com.example.repo.ProductRepo;
import com.example.serviceImpl.ProductServiceImpl;

@ExtendWith(MockitoExtension.class)
public class ProductServiceTest {

    @Mock
    private ProductRepo productRepo;

    @Mock
    private OrderItemRepo orderItemRepo;

    @Mock
    private OrderRepo orderRepo;

    @Mock
    private CartRepo cartRepo;

    @InjectMocks
    private ProductServiceImpl productService;

    private Product product;
    private Category category;

    @BeforeEach
    public void setUp() {
        category = new Category(1L, "Electronics");
        product = new Product(1L, "Laptop", "High-end laptop", 1200.00, 10, category, "imageData");
    }

    @Test
    public void testAddProduct() {
        when(productRepo.save(any(Product.class))).thenReturn(product);

        Product savedProduct = productService.addProduct(product);

        assertNotNull(savedProduct);
        assertEquals(product.getProduct_name(), savedProduct.getProduct_name());
        verify(productRepo, times(1)).save(product);
    }

    @Test
    public void testGetAllProducts() {
        List<Product> products = Arrays.asList(product);
        when(productRepo.findAll()).thenReturn(products);

        List<Product> result = productService.getAllProducts();

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(productRepo, times(1)).findAll();
    }

    @Test
    public void testGetProductById() {
        when(productRepo.findById(anyLong())).thenReturn(Optional.of(product));

        Product result = productService.getProductById(1L);

        assertNotNull(result);
        assertEquals(product.getProduct_name(), result.getProduct_name());
        verify(productRepo, times(1)).findById(1L);
    }

    @Test
    public void testUpdateProduct() {
        when(productRepo.save(any(Product.class))).thenReturn(product);

        Product updatedProduct = productService.updateProduct(product);

        assertNotNull(updatedProduct);
        assertEquals(product.getProduct_name(), updatedProduct.getProduct_name());
        verify(productRepo, times(1)).save(product);
    }
}
