package com.example.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.model.Order;
import com.example.model.Payment;
import com.example.model.User;
import com.example.repo.OrderRepo;
import com.example.repo.PaymentRepo;
import com.example.serviceImpl.OrderServiceImpl;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {

    @Mock
    private OrderRepo orderRepo;

    @Mock
    private PaymentRepo paymentRepo;

    @InjectMocks
    private OrderServiceImpl orderService;

    private User user;
    private Order order;
    private Payment payment;

    @BeforeEach
    public void setUp() {
        user = new User();
        user.setUserid(1L);

        order = new Order();
        order.setOrderid(1L);
        order.setUser(user);
        order.setTotalAmount(100.0);

        payment = new Payment();
        payment.setPaymentid(1L); // Use the correct field name
        payment.setOrder(order);
        payment.setAmount(100.0);
        payment.setPaymentMethod("Credit Card");
        payment.setPaymentDate(new Date());
    }


    @Test
    public void testSaveOrder() {
        when(orderRepo.save(any(Order.class))).thenReturn(order);

        orderService.saveOrder(order);

        verify(orderRepo, times(1)).save(order);
    }

    @Test
    public void testSavePayment() {
        when(paymentRepo.save(any(Payment.class))).thenReturn(payment);

        orderService.savePayment(payment);

        verify(paymentRepo, times(1)).save(payment);
    }

    @Test
    public void testFindByUser() {
        List<Order> orders = Arrays.asList(order);
        when(orderRepo.findByUser(any(User.class))).thenReturn(orders);

        List<Order> result = orderService.findByUser(user);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(orderRepo, times(1)).findByUser(user);
    }

    @Test
    public void testFindAll() {
        List<Order> orders = Arrays.asList(order);
        when(orderRepo.findAll()).thenReturn(orders);

        List<Order> result = orderService.findAll();

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(orderRepo, times(1)).findAll();
    }

    @Test
    public void testFindById() {
        when(orderRepo.findById(anyLong())).thenReturn(Optional.of(order));

        Optional<Order> result = orderService.findById(1L);

        assertTrue(result.isPresent());
        assertEquals(order.getOrderid(), result.get().getOrderid());
        verify(orderRepo, times(1)).findById(1L);
    }

    @Test
    public void testSave() {
        when(orderRepo.save(any(Order.class))).thenReturn(order);

        orderService.save(order);

        verify(orderRepo, times(1)).save(order);
    }

    @Test
    public void testFindByOrder() {
        List<Order> orders = Arrays.asList(order);
        when(orderRepo.findByOrderid(anyLong())).thenReturn(orders);

        List<Order> result = orderService.findByOrder(order);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(orderRepo, times(1)).findByOrderid(order.getOrderid());
    }
}
